#!/system/bin/sh
MODDIR=${0%/*}

# Refresh PackageManager cache for SimTool only (user app data in /data/data/com.simtool is untouched)
rm -rf /data/system/package_cache/*/SimTool* /data/system/package_cache/*/com.simtool* 2>/dev/null || true

# Apply standard system_file SELinux context if chcon is available
if command -v chcon >/dev/null 2>&1; then
  chcon -R u:object_r:system_file:s0 "$MODDIR/system" 2>/dev/null || true
fi
