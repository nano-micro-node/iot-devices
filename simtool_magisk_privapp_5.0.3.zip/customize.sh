#!/system/bin/sh
SKIPUNZIP=0

ui_print "=============================================="
ui_print " SIM Tool System Priv-App Elevation v5.0.3 (vc62)"
ui_print "=============================================="
ui_print "- Installing /system/priv-app/SimTool/SimTool.apk"
ui_print "- Installing /system/etc/permissions/privapp-permissions-com.simtool.xml"
ui_print "- Existing Device Owner (e.g. com.temslicence) is preserved"

set_perm_recursive "$MODPATH/system/priv-app" 0 0 0755 0644
set_perm_recursive "$MODPATH/system/etc/permissions" 0 0 0755 0644
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755

ui_print "- Done. Reboot device to activate SYSTEM PRIVILEGED flags."
